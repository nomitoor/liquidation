@extends('layouts/contentLayoutMaster')

@section('title', 'Home')

@section('content')
<div class="card">

</div>
@endsection