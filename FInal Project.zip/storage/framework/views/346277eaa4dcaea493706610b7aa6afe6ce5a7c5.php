

<?php $__env->startSection('title', 'All Pallets'); ?>

<?php $__env->startSection('vendor-style'); ?>

<link rel="stylesheet" href="<?php echo e(asset(mix('vendors/css/tables/datatable/dataTables.bootstrap4.min.css'))); ?>">
<link rel="stylesheet" href="<?php echo e(asset(mix('vendors/css/tables/datatable/responsive.bootstrap4.min.css'))); ?>">
<link rel="stylesheet" href="<?php echo e(asset(mix('vendors/css/pickers/flatpickr/flatpickr.min.css'))); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-style'); ?>

<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/base/plugins/forms/pickers/form-flat-pickr.css')); ?>">
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<!-- Ajax Sourced Server-side -->
<section id="ajax-datatable">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header border-bottom">
                    <h4 class="card-title">All Pallets</h4>
                    <a class="btn btn-primary" href="<?php echo e(route('pallets.create')); ?>">Create Pallets</a>
                </div>
                <div class="card-datatable">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>pallet id</th>
                                <th>Category</th>
                                <th>Total price</th>
                                <th>Total units</th>
                                <th>Created At</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $pallets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pallet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e('DE'.sprintf("%05d", $pallet->id)); ?></td>
                                <td><?php echo e($pallet->category->title ?? '-'); ?></td>
                                <td><?php echo e($pallet->total_price); ?></td>
                                <td><?php echo e($pallet->total_unit); ?></td>
                                <td><?php echo e($pallet->created_at); ?></td>
                                <td>
                                    <a href="<?php echo e(route('pallets.show', $pallet->id)); ?>" class="btn btn-warning btn-sm">
                                        View
                                    </a>
                                    <a href="<?php echo e(route('pallets.edit', $pallet->id)); ?>" class="btn btn-info btn-sm">
                                        Edit
                                    </a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</section>

<!--/ Ajax Sourced Server-side -->
<?php $__env->stopSection(); ?>


<?php $__env->startSection('vendor-script'); ?>

<script src="<?php echo e(asset(mix('vendors/js/tables/datatable/jquery.dataTables.min.js'))); ?>"></script>
<script src="<?php echo e(asset(mix('vendors/js/tables/datatable/datatables.bootstrap4.min.js'))); ?>"></script>
<script src="<?php echo e(asset(mix('vendors/js/tables/datatable/dataTables.responsive.min.js'))); ?>"></script>
<script src="<?php echo e(asset(mix('vendors/js/tables/datatable/responsive.bootstrap4.js'))); ?>"></script>
<script src="<?php echo e(asset(mix('vendors/js/pickers/flatpickr/flatpickr.min.js'))); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-script'); ?>

<!-- <script src="<?php echo e(asset(mix('js/scripts/tables/table-datatables-advanced.js'))); ?>"></script> -->

<script>
    function viewProducts(id) {
        alert(id)
    }

    function getManifest(id) {
        $.ajax({
            type: 'POST',
            url: '<?php echo route('scanned-manifests') ?>',
            data: {
                '_token': '<?php echo csrf_token() ?>',
                'id': id
            },
            success: function(data) {

                if (data.code == '201') {
                    $('.open-modal').click();
                    var table = document.getElementById("myTable");
                    var unit_count = 0;
                    var total_cost = 0;
                    table.innerHTML = "";

                    data.data.forEach((manifest) => {
                        var row = table.insertRow(0);
                        var cell0 = row.insertCell(0);
                        var cell1 = row.insertCell(1);
                        var cell2 = row.insertCell(2);
                        var cell3 = row.insertCell(3);

                        unit_count += parseInt(manifest.units)
                        total_cost = parseFloat(total_cost) + parseFloat(manifest.total_cost)

                        cell0.innerHTML = manifest.item_description;
                        cell1.innerHTML = manifest.units;
                        cell2.innerHTML = manifest.unit_cost;
                        cell3.innerHTML = manifest.total_cost;

                    })
                    $('.total_units').html(unit_count)
                    $('.total_costs').html(total_cost.toFixed(2))

                } else {
                    alert("Nothing found against your ID please try with a valid ID");
                }
            }
        });
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/contentLayoutMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ashir.muhammad\Desktop\FInal Project\resources\views/pallets/pallets.blade.php ENDPATH**/ ?>