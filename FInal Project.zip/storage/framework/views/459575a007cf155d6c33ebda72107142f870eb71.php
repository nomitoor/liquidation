<?php $__env->startSection('title', 'Manifest'); ?>

<?php $__env->startSection('vendor-style'); ?>

<link rel="stylesheet" href="<?php echo e(asset(mix('vendors/css/tables/datatable/dataTables.bootstrap4.min.css'))); ?>">
<link rel="stylesheet" href="<?php echo e(asset(mix('vendors/css/tables/datatable/responsive.bootstrap4.min.css'))); ?>">
<link rel="stylesheet" href="<?php echo e(asset(mix('vendors/css/pickers/flatpickr/flatpickr.min.css'))); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-style'); ?>

<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/base/plugins/forms/pickers/form-flat-pickr.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <!-- Responsive Datatable -->
    <section id="responsive-datatable">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header border-bottom">
                        <h4 class="card-title">All Products</h4>
                        <a class="btn btn-primary" href="<?php echo e(route('manifest.create')); ?>">Upload File</a>
                    </div>
                    <div class="card-datatable">
                        <table class="dt-responsive table">
                            <thead>
                                <tr>
                                    <th>Bol</th>
                                    <th>Package Id</th>
                                    <th>Item Description</th>
                                    <th>Units</th>
                                    <th>Unit Cost</th>
                                    <th>Total Cost</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $manifest; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mani): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($mani->bol); ?></td>
                                    <td><?php echo e($mani->package_id); ?></td>
                                    <td><?php echo e($mani->item_description); ?></td>
                                    <td><?php echo e($mani->units); ?></td>
                                    <td><?php echo e($mani->unit_cost); ?></td>
                                    <td><?php echo e($mani->total_cost); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                            <tfoot>
                                <tr>
                                    <th>Bol</th>
                                    <th>Package Id</th>
                                    <th>Item Description</th>
                                    <th>Units</th>
                                    <th>Unit Cost</th>
                                    <th>Total Cost</th>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--/ Responsive Datatable -->
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('vendor-script'); ?>

<script src="<?php echo e(asset(mix('vendors/js/tables/datatable/jquery.dataTables.min.js'))); ?>"></script>
<script src="<?php echo e(asset(mix('vendors/js/tables/datatable/datatables.bootstrap4.min.js'))); ?>"></script>
<script src="<?php echo e(asset(mix('vendors/js/tables/datatable/dataTables.responsive.min.js'))); ?>"></script>
<script src="<?php echo e(asset(mix('vendors/js/tables/datatable/responsive.bootstrap4.js'))); ?>"></script>
<script src="<?php echo e(asset(mix('vendors/js/pickers/flatpickr/flatpickr.min.js'))); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-script'); ?>

<script src="<?php echo e(asset(mix('js/scripts/tables/table-datatables-advanced.js'))); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/contentLayoutMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nomi/Desktop/liquidation-8.0/resources/views/manifest/manifest.blade.php ENDPATH**/ ?>